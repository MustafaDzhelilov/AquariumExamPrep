package aquarium.entities.fish;

public interface Fish {
    void setName(String name);

    int eat();

    int getSize();

    String getName();

    double getPrice();
}
